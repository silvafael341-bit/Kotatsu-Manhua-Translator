package org.koitharu.kotatsu.translation.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

class GoogleTranslateClient(
    private val httpClient: OkHttpClient = OkHttpClient(),
) {
    suspend fun translate(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext ""
        val url = "https://translate.googleapis.com/translate_a/single".toHttpUrl().newBuilder()
            .addQueryParameter("client", "gtx")
            .addQueryParameter("sl", source.ifBlank { "auto" })
            .addQueryParameter("tl", target)
            .addQueryParameter("dt", "t")
            .addQueryParameter("q", text)
            .build()
        val request = Request.Builder().url(url).get().build()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Google Translate HTTP ${response.code}")
            val body = response.body?.string().orEmpty()
            val root = JSONArray(body)
            val translations = root.optJSONArray(0) ?: return@withContext ""
            buildString {
                for (i in 0 until translations.length()) {
                    val part = translations.optJSONArray(i)?.optString(0).orEmpty()
                    if (part.isNotBlank()) append(part)
                }
            }
        }
    }
}
