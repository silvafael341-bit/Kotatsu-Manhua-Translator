package org.koitharu.translator.ocr

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Multilingual OCR.
 *
 * We deliberately run the four useful script recognizers over 0/90/270-degree
 * versions of the page. Results are mapped back to the original coordinates
 * and then spatially de-duplicated instead of simply selecting the longest
 * OCR string.
 */
class OcrEngine : AutoCloseable {

    private data class Candidate(
        val block: TextBlock,
        val score: Float,
    )

    private val recognizers: List<Pair<String, TextRecognizer>> = listOf(
        "zh" to TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
        "ja" to TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
        "ko" to TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
        "en" to TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
    )

    suspend fun scan(bitmap: Bitmap): List<TextBlock> {
        if (bitmap.width < 2 || bitmap.height < 2) return emptyList()

        val candidates = mutableListOf<Candidate>()

        for (rotation in ROTATIONS) {
            val rotated = if (rotation == 0) {
                bitmap
            } else {
                rotate(bitmap, rotation)
            }

            try {
                for ((language, recognizer) in recognizers) {
                    runCatching {
                        recognizer.process(InputImage.fromBitmap(rotated, 0)).await()
                    }.onSuccess { result ->
                        result.textBlocks.forEach { block ->
                            block.lines.forEach { line ->
                                val text = line.text.trim()
                                val box = line.boundingBox ?: return@forEach
                                if (text.length < 1) return@forEach

                                val mapped = mapRect(
                                    box,
                                    rotation,
                                    bitmap.width,
                                    bitmap.height,
                                )
                                val vertical = rotation != 0 ||
                                    mapped.height() > mapped.width() * 1.25f
                                val confidence = runCatching {
                                    line.confidence ?: 0.5f
                                }.getOrDefault(0.5f)

                                val tb = TextBlock(
                                    text = text,
                                    boundingBox = mapped,
                                    confidence = confidence,
                                    language = language,
                                    vertical = vertical,
                                )
                                candidates += Candidate(
                                    tb,
                                    tb.score() + scriptBonus(text, language),
                                )
                            }
                        }
                    }
                }
            } finally {
                if (rotation != 0 && rotated !== bitmap) {
                    rotated.recycle()
                }
            }
        }

        return selectBestCandidates(candidates, bitmap.width, bitmap.height)
    }

    private fun selectBestCandidates(
        candidates: List<Candidate>,
        width: Int,
        height: Int,
    ): List<TextBlock> {
        val result = mutableListOf<TextBlock>()
        val sorted = candidates
            .filter { it.block.boundingBox.width() > 2 && it.block.boundingBox.height() > 2 }
            .sortedByDescending { it.score }

        for (candidate in sorted) {
            val box = candidate.block.boundingBox
            if (result.any { iou(it.boundingBox, box) >= IOU_DUPLICATE_THRESHOLD }) {
                continue
            }
            result += candidate.block
        }

        return result
            .sortedWith(
                compareBy<TextBlock> { it.boundingBox.top }
                    .thenBy { it.boundingBox.left },
            )
            .take(MAX_BLOCKS_PER_PAGE)
    }

    private fun scriptBonus(text: String, language: String): Float {
        var cjk = 0
        var kana = 0
        var hangul = 0
        var latin = 0

        for (ch in text) {
            when {
                ch in '\u3040'..'\u30ff' -> kana++
                ch in '\uac00'..'\ud7af' -> hangul++
                ch in '\u4e00'..'\u9fff' -> cjk++
                ch.isLetter() && ch.code < 0x0250 -> latin++
            }
        }

        val total = max(1, cjk + kana + hangul + latin)
        return when (language) {
            "ja" -> ((kana * 2 + cjk) / total.toFloat()).coerceAtMost(1f) * 2f
            "ko" -> (hangul / total.toFloat()).coerceAtMost(1f) * 2f
            "zh" -> (cjk / total.toFloat()).coerceAtMost(1f) * 2f
            else -> (latin / total.toFloat()).coerceAtMost(1f) * 2f
        }
    }

    private fun rotate(bitmap: Bitmap, degrees: Int): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            matrix,
            true,
        )
    }

    private fun mapRect(
        rect: Rect,
        rotation: Int,
        originalWidth: Int,
        originalHeight: Int,
    ): Rect {
        val mapped = when (rotation) {
            90 -> Rect(
                rect.top,
                originalHeight - rect.right,
                rect.bottom,
                originalHeight - rect.left,
            )
            270 -> Rect(
                originalWidth - rect.bottom,
                rect.left,
                originalWidth - rect.top,
                rect.right,
            )
            else -> Rect(rect)
        }

        mapped.left = mapped.left.coerceIn(0, originalWidth)
        mapped.right = mapped.right.coerceIn(0, originalWidth)
        mapped.top = mapped.top.coerceIn(0, originalHeight)
        mapped.bottom = mapped.bottom.coerceIn(0, originalHeight)

        if (mapped.right <= mapped.left) mapped.right = min(originalWidth, mapped.left + 1)
        if (mapped.bottom <= mapped.top) mapped.bottom = min(originalHeight, mapped.top + 1)

        return mapped
    }

    private fun iou(a: Rect, b: Rect): Float {
        val left = max(a.left, b.left)
        val top = max(a.top, b.top)
        val right = min(a.right, b.right)
        val bottom = min(a.bottom, b.bottom)
        val intersection = max(0, right - left) * max(0, bottom - top)
        if (intersection == 0) return 0f

        val areaA = max(1, a.width() * a.height())
        val areaB = max(1, b.width() * b.height())
        return intersection.toFloat() / (areaA + areaB - intersection).toFloat()
    }

    override fun close() {
        recognizers.forEach { it.second.close() }
    }

    companion object {
        private val ROTATIONS = intArrayOf(0, 90, 270)
        private const val IOU_DUPLICATE_THRESHOLD = 0.62f
        private const val MAX_BLOCKS_PER_PAGE = 250
    }
}

private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
    suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { value ->
            if (continuation.isActive) continuation.resume(value)
        }
        addOnFailureListener { error ->
            if (continuation.isActive) continuation.resumeWithException(error)
        }
        addOnCanceledListener {
            continuation.cancel()
        }
    }
