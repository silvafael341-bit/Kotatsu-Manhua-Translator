@file:Suppress("unused")

package org.koitharu.translator.translate
