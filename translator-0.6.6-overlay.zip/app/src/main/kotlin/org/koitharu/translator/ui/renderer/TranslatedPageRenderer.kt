package org.koitharu.translator.ui.renderer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import org.koitharu.translator.ocr.TextRegion
import kotlin.math.max
import kotlin.math.min

/**
 * Renders a translated page as a normal bitmap.
 *
 * This avoids coordinate drift between an overlay and SubsamplingScaleImageView
 * zoom/pan transforms. The erase area is inset so balloon borders and artwork
 * immediately outside the OCR region are not painted over.
 */
class TranslatedPageRenderer {

    fun render(
        original: Bitmap,
        regions: List<TextRegion>,
        translations: List<String>,
    ): Bitmap {
        val output = original.copy(Bitmap.Config.ARGB_8888, true)

        val count = min(regions.size, translations.size)
        for (index in 0 until count) {
            val region = regions[index]
            val translation = translations[index].trim()
            if (translation.isBlank()) continue

            val rect = region.boundingBox.intersected(
                Rect(0, 0, output.width, output.height),
            ) ?: continue

            val padded = Rect(
                max(0, rect.left - 2),
                max(0, rect.top - 2),
                min(output.width, rect.right + 2),
                min(output.height, rect.bottom + 2),
            )

            val bg = estimateBackground(output, padded)
            eraseTextArea(output, padded, bg)
            drawText(output, translation, padded, region.vertical, bg)
        }

        return output
    }

    private fun eraseTextArea(bitmap: Bitmap, rect: Rect, background: Int) {
        val inset = Rect(
            rect.left + 2,
            rect.top + 2,
            rect.right - 2,
            rect.bottom - 2,
        )
        if (inset.width() <= 1 || inset.height() <= 1) return

        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = background
            style = Paint.Style.FILL
        }
        canvas.drawRect(inset, paint)
    }

    private fun estimateBackground(bitmap: Bitmap, rect: Rect): Int {
        val samples = ArrayList<Int>(32)
        val x0 = rect.left.coerceAtLeast(0)
        val x1 = (rect.right - 1).coerceAtMost(bitmap.width - 1)
        val y0 = rect.top.coerceAtLeast(0)
        val y1 = (rect.bottom - 1).coerceAtMost(bitmap.height - 1)
        if (x1 < x0 || y1 < y0) return Color.WHITE

        val stepX = max(1, rect.width() / 6)
        val stepY = max(1, rect.height() / 6)

        for (x in x0..x1 step stepX) {
            samples += bitmap.getPixel(x, y0)
            samples += bitmap.getPixel(x, y1)
        }
        for (y in y0..y1 step stepY) {
            samples += bitmap.getPixel(x0, y)
            samples += bitmap.getPixel(x1, y)
        }

        if (samples.isEmpty()) return Color.WHITE

        var r = 0L
        var g = 0L
        var b = 0L
        samples.forEach {
            r += Color.red(it)
            g += Color.green(it)
            b += Color.blue(it)
        }
        return Color.rgb(
            (r / samples.size).toInt(),
            (g / samples.size).toInt(),
            (b / samples.size).toInt(),
        )
    }

    private fun drawText(
        bitmap: Bitmap,
        text: String,
        rect: Rect,
        vertical: Boolean,
        background: Int,
    ) {
        val inset = Rect(
            rect.left + 5,
            rect.top + 5,
            rect.right - 5,
            rect.bottom - 5,
        )
        if (inset.width() <= 4 || inset.height() <= 4) return

        val canvas = Canvas(bitmap)
        val lightBackground =
            (0.299 * Color.red(background) +
                0.587 * Color.green(background) +
                0.114 * Color.blue(background)) >= 150.0

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (lightBackground) Color.rgb(25, 25, 25) else Color.WHITE
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            setShadowLayer(1.5f, 0f, 0f, if (lightBackground) Color.WHITE else Color.BLACK)
        }

        if (vertical) {
            drawVertical(canvas, text, inset, paint)
        } else {
            drawHorizontal(canvas, text, inset, paint)
        }
    }

    private fun drawHorizontal(canvas: Canvas, text: String, rect: Rect, paint: Paint) {
        var size = (rect.height() * 0.72f).coerceIn(10f, 96f)
        var lines = breakLines(text, paint.apply { textSize = size }, rect.width())

        while (lines.size * size * 1.18f > rect.height() && size > 8f) {
            size *= 0.88f
            paint.textSize = size
            lines = breakLines(text, paint, rect.width())
        }

        val lineHeight = size * 1.18f
        val totalHeight = lines.size * lineHeight
        var baseline = rect.top + (rect.height() - totalHeight) / 2f - paint.fontMetrics.ascent

        for (line in lines) {
            canvas.drawText(line, rect.centerX().toFloat(), baseline, paint)
            baseline += lineHeight
            if (baseline > rect.bottom + size) break
        }
    }

    private fun drawVertical(canvas: Canvas, text: String, rect: Rect, paint: Paint) {
        var size = (rect.width() * 0.72f).coerceIn(10f, 72f)
        paint.textSize = size

        val chars = text.replace("\n", "").toList()
        if (chars.isEmpty()) return

        val spacing = size * 1.12f
        while (chars.size * spacing > rect.height() && size > 8f) {
            size *= 0.88f
            paint.textSize = size
        }

        val total = chars.size * spacing
        var y = rect.top + (rect.height() - total) / 2f + size
        val x = rect.centerX().toFloat()

        for (ch in chars) {
            canvas.drawText(ch.toString(), x, y, paint)
            y += spacing
            if (y > rect.bottom + size) break
        }
    }

    private fun breakLines(text: String, paint: Paint, width: Int): List<String> {
        val lines = mutableListOf<String>()
        var current = StringBuilder()

        fun flush() {
            if (current.isNotEmpty()) {
                lines += current.toString()
                current = StringBuilder()
            }
        }

        for (ch in text) {
            if (ch == '\n') {
                flush()
                continue
            }

            val candidate = current.toString() + ch
            if (current.isNotEmpty() && paint.measureText(candidate) > width) {
                flush()
            }
            current.append(ch)
        }
        flush()

        return if (lines.isEmpty()) listOf("") else lines
    }

    private fun Rect.intersected(other: Rect): Rect? {
        val out = Rect(this)
        return if (out.intersect(other)) out else null
    }
}
