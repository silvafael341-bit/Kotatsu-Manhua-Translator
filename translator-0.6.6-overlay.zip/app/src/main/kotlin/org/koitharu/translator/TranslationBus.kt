package org.koitharu.translator

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Lightweight bridge between the reader overflow menu and the currently
 * attached page holder. The event contains the ReaderPage id, so other
 * visible/preloaded holders ignore it.
 */
object TranslationBus {
    private val _requests = MutableSharedFlow<Long>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    val requests = _requests.asSharedFlow()

    fun request(pageId: Long) {
        _requests.tryEmit(pageId)
    }
}
